import { Component } from "@angular/core";
import {
  IonicPage,
  NavController,
  NavParams,
  ToastController,
  ToastOptions,
} from "ionic-angular";
import { NewsProvider } from "../../providers/news/news";
// Import Storage
import { Storage } from "@ionic/storage";
/**
 * Generated class for the NewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-news",
  templateUrl: "news.html",
})
export class NewsPage {
  newsArticles: any[];
  newsTotalResults: number;
  pageSize: number = 5;
  // Toast
  toastOptions: ToastOptions;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private np: NewsProvider,
    private storage: Storage,
    private toastCtrl: ToastController
  ) {}

  // Country Code to Display i.e. [IE]
  public country_code: string;
  // No News Message visible by Default.
  public noNews: boolean = false;
  // News Displayed by Default.
  public news: boolean = true;

  ionViewWillEnter() {
    // Before entering, retrieve news for Country based on Country Code i.e. [IE]
    console.log("[ionViewWillEnter] News Page Entered, Loaded!");
    this.getCountry();
  }

  getCountry() {
    // Retrieve the Country Code from the settings data from Storage.
    // Fulfill using Promise
    this.storage
      .get("settings")
      .then((data) => {
        if (data != null) {
          // (data is stored from settings in Storage)
          // Return Object as JSON Strings.
          let settings = JSON.parse(data);
          // Get the country_code from the the settings object in Storage.
          this.country_code = settings.country_code;
          // Show the settings Data in Storage.
          console.log("settings Data in Storage ->>>> " + data);
          // Show the country_code
          console.log("country_code ->>>>>>>>> " + this.country_code);

          // Get the news from the news provider relating to the country_code in Storage.
          this.np.getNews(this.country_code).subscribe((data) => {
            // Console log the articles.
            console.log(data);
            // Get total results value available from Request to display on the page.
            this.newsTotalResults = data.totalResults;
            // Define Array of Articles to display.
            this.newsArticles = data.articles;
            // Show the HTTP Request Status
            console.log(
              "HTTP Request Status returned from API -> " + data.status
            );

            // Get HTTP Request Status and article count check.
            if (data.status == "ok" && data.totalResults == 0) {
              // If the HTTP request was successful, there was just no articles coming back...
              console.log(
                "->> HTTP Request was successful, there was just no articles..."
              );
              // Hide no news from .. message.
              this.noNews = false;
              // Show news from .. message.
              this.news = true;
            } else {
              // Forget about the HTTP Request status and results just..
              // alert("else block run");
              // Hide no news from .. message.
              this.noNews = true;
              // Show news from .. message.
              this.news = false;
              this.newsFoundToast();
            }
          }),
            (err) => {
              // Console log error on unsuccessful Observable request.
              console.log(err);
              console.log(
                "--> Unsuccessful Result Received from the News Provider.."
              );
            };
        } else {
          // (no data stored in settings object in Storage)
          // Unreachable code as button to reach this page is only visible if the weather is found.
          console.log("Local Storage Accessed, Nothing was Saved!");
        }
      })
      .catch((error) => {
        alert("Error Accessing Local Storage on News Page!");
        console.log(error);
      });
  }
  newsFoundToast() {
    // https://ionicframework.com/docs/v3/api/components/toast/ToastController/
    // countryCommonName -> white space kept as using common name direct from API. (not from storage)
    this.toastOptions = {
      message: "✔️ Updating News",
      position: "top",
      duration: 2000,
      showCloseButton: true,
      // cssClass: "color: red;",
    };
    this.toastCtrl.create(this.toastOptions).present();
  }
}
