import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

/*
  Generated class for the CountryProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class CountryProvider {
  /*
__________ ___________  ____________________
\______   \\_   _____/ /   _____/\__    ___/
 |       _/ |    __)_  \_____  \   |    |   
 |    |   \ |        \ /        \  |    |   
 |____|_  //_______  //_______  /  |____|   
        \/         \/         \/            
_________  ________    ____ ___ _______ _____________________ .___ ___________  _________
\_   ___ \ \_____  \  |    |   \\      \\__    ___/\______   \|   |\_   _____/ /   _____/
/    \  \/  /   |   \ |    |   //   |   \ |    |    |       _/|   | |    __)_  \_____  \ 
\     \____/    |    \|    |  //    |    \|    |    |    |   \|   | |        \ /        \
 \______  /\_______  /|______/ \____|__  /|____|    |____|_  /|___|/_______  //_______  /
        \/         \/                  \/                  \/              \/         \/ 
  Get information about countries via a RESTful API
  -> No API Key Required.

  https://restcountries.com/#api-endpoints-v3

    Get's all countries
    https://restcountries.com/v3.1/all

    Example Request -> Search cca2 for Ireland by using ie country code -> 
    https://restcountries.com/v3.1/alpha/ie 
    
*/

  constructor(public http: HttpClient) {
    console.log("Hello CountryProvider Provider");
  }

  // Return all Countries, to Array Map over Country Names -> Retrieve List of Country Names.
  getAllCountries(): Observable<any> {
    return this.http.get(`https://restcountries.com/v3.1/all`);
  }

  //  Return Country Details for a Specific Country -> Retrieve Flag, Common Name.
  getCountry(country_code: string): Observable<any> {
    return this.http.get(
      `https://restcountries.com/v3.1/alpha/${country_code}`
    );
  }
}
