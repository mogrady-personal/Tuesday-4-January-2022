import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
// Import
import { Observable } from "rxjs";

/*
  Generated class for the NewsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class NewsProvider {
  /*

 _______                         _____ __________.___ 
 \      \   ______  _  ________ /  _  \\______   \   |
 /   |   \_/ __ \ \/ \/ /  ___//  /_\  \|     ___/   |
/    |    \  ___/\     /\___ \/    |    \    |   |   |
\____|__  /\___  >\/\_//____  >____|__  /____|   |___|
        \/     \/           \/        \/              
  Search worldwide news with code -> NewsAPI
  
  https://newsapi.org/account
    API KEY: 9c95e62f3a2345a68798078e8170e424

      Example Request
      -> Top Headlines Around the World
      https://newsapi.org/v2/top-headlines/sources?apiKey=9c95e62f3a2345a68798078e8170e424

      Example Request
      -> Top 5 Headlines from Ireland
      https://newsapi.org/v2/top-headlines?country=ie&pageSize=5&apiKey=9c95e62f3a2345a68798078e8170e424

      https://newsapi.org/docs/endpoints/everything
  */
  pageSize: number = 5; // The number of results to return per page.
  API_KEY: string = "9c95e62f3a2345a68798078e8170e424";

  constructor(public http: HttpClient) {
    console.log("Hello NewsProvider Provider");
  }

  getNews(country_code: string): Observable<any> {
    // Get the top headlines relating to the Country Code with a defined number of articles.
    return this.http.get(
      `https://newsapi.org/v2/top-headlines?country=${country_code}&pageSize=${this.pageSize}&apiKey=${this.API_KEY}`
    );
  }
}
