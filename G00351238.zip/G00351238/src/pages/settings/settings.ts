import { Component } from "@angular/core";
import {
  IonicPage,
  NavController,
  NavParams,
  ToastController,
  ToastOptions,
} from "ionic-angular";
import { Storage } from "@ionic/storage";
// Alert
import { AlertController } from "ionic-angular";
// Toast
// Provider to return list of Countries for Select
import { CountryProvider } from "../../providers/country/country";
/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-settings",
  templateUrl: "settings.html",
})
export class SettingsPage {
  // Page Title
  title: string = "Settings";

  // Settings Page — Instance Variables
  unit: string;
  textInput: string;
  city_name: string;
  country_code: string;

  // Toast
  toastOptions: ToastOptions;

  // Array of Countries for the Select
  allCountries: any[];

  // Selected Country from the Select
  user_selected_country: string;
  // Additional Details
  countryFlag: string; // Flag
  countryCommonName: string; // Common Name

  // Temperature Symbol for Switch Statement
  public tempSymbol: string;
  // Save Button Hidden by Default
  waitForUpdate: boolean = true;
  // Delete Saved Storage Button Hidden by Default
  storageSaved: boolean = true;
  // Clear City Button Hidden by Default
  cityFilled: boolean = true;
  // Common Name is set in Storage (retrieved and set as select value if saved (instead of the user_selected_country, which has white space replaced inside the string for accurate API Weather Request)
  common_name: string;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private storage: Storage,
    // Alert
    public alertCtrl: AlertController,
    // Toast
    private toastCtrl: ToastController,
    private cp: CountryProvider
  ) {}

  /*
  ** Notes **
  ionViewDidLoad
  https://ionicframework.com/blog/navigating-lifecycle-events/
   ** Fired only when a view is stored in memory. **
   ** This event is NOT fired on entering a view that is already cached. **
  */
  // ionViewDidLoad() {
  //   console.log("[ionViewDidLoad] -> Settings Page — Was Already Cached!");
  //   this.common_name = this.user_selected_country;
  // }

  /*
  ionViewWillEnter
  https://ionicframework.com/blog/navigating-lifecycle-events/
   **  fired when entering a page, before it becomes the active one.  **
      Use for tasks you want to do every time you enter in the view (setting event listeners, updating a table, etc.)
  */
  ionViewWillEnter() {
    console.log("[ionViewWillEnter] Settings Page Entered, Loaded!");
    // Return a list of Countries for the Select.
    this.retrieveCountryList();
    // Access Storage and check if there is a settings Object
    this.storage
      .get("settings")
      .then((data) => {
        if (data != null) {
          // If there is, return the elements as JSON Strings
          let settings = JSON.parse(data);
          // Set fields/data on the page
          this.city_name = settings.city_name;
          this.unit = settings.unit;
          this.country_code = settings.country_code;
          this.user_selected_country = settings.common_name;
          console.log("Local Storage Accessed");
          console.log("The Following Settings (data) is Saved in JSON format:");
          console.log(data); // Display the Object as a String
          console.log(settings); // parse the JSON to Display the Object as Key Value Pairs to make them easier to view
          // Show the Delete Saved Storage Button
          this.storageSaved = false;
          this.cityFilled = false;
        } else {
          // Set Page Defaults
          this.unit = "M";
          console.log("Local Storage Accessed, Nothing is Saved!");
        }
      })
      .catch((error) => {
        alert("Error Accessing Local Storage on Settings Page!");
        console.log(error);
      });
  }

  /*
  ionViewDidEnter
  https://ionicframework.com/blog/navigating-lifecycle-events/
  Fired when entering a page, ** after it becomes the active page.**
  */
  ionViewDidEnter() {
    console.log("[ionViewDidEnter] Settings Page Active, and Loaded!");
  }

  // Alert for Empty City
  emptyCityAlert() {
    // https://ionicframework.com/docs/v3/api/components/alert/AlertController/
    const alert = this.alertCtrl.create({
      // title: "⚠️",
      subTitle: "⚠️ Must enter City and Country",
      buttons: ["OK"],
      mode: "md",
      // mode: "ios",
    });
    alert.present();
  }

  retrieveCountryList() {
    // Retrieve a list of All Countries to make available to the Select (from restcountries).
    this.cp.getAllCountries().subscribe(
      (data) => {
        if (data) {
          console.log("Return Data for All Countries in a JSON Object:");
          console.log(data); // Return's Data (of all 250 Countries).

          console.log("New Countries Array:");
          // Use Array Map to Return an array element: [name.common]
          const countries = data.map((country) => country.name.common);
          // Return a Sorted Array of Countries in Alphabetical Order.
          console.log(countries.sort());

          // Create an JSON Object of Country Names accessable to the Select.
          const countryList = countries.map(function (common) {
            let arr = {
              name: common,
            };
            return arr;
          });
          console.log(countryList);
          this.allCountries = countryList;
        } else {
          console.log("No Data Coming through REST Countries API");
        }
      },
      (error) => {
        console.log(error);
        console.log("No Data Coming Back From restcountries API");
        this.connectionErrorToast();
      }
    );
  }

  selectOnChange() {
    // Hide the Save Button initially, until the country_code is found for the user_selected_country.
    // Failure to to this results in the country_code not being set if the user presses save before the matching country code is returned.
    this.waitForUpdate = true;
    // Show the User Selected Country
    console.log("user_selected_country -> " + this.user_selected_country);
    console.log("country_code was -> " + this.country_code); // At this point the Country Code is undefined

    // Get the cca2 (country_code) based on the Select (user_selected_country)
    this.cp.getAllCountries().subscribe(
      (data) => {
        if (data) {
          // console.log("Return Data for All Countries in a JSON Object:");
          // console.log(data); // Return's Data (of all 250 Countries)
          // Filter the Data by the Country Common name == Select
          const result = data.filter(
            (cca2) => this.user_selected_country == cca2.name.common
          );
          // console.log(result[0].cca2); // Return the Match of cca2 -> Relating to the Select
          this.country_code = result[0].cca2; // At this point, Set the country_code = cca2 value
          console.log("country_code now -> " + this.country_code);
          this.pleaseWait();
          this.waitForUpdate = false;
        } else {
          console.log("No Data Coming through REST Countries API");
        }
      },
      (error) => {
        // Unreachable code as Select is unable to provide options on change.
        console.log(error);
        console.log("No Data Coming Back From restcountries API");
      }
    );
  }

  saveSettings() {
    // Check the value of user_selected_country on Page Save
    // Check to ensire City and Country are not is empty or null.
    if (
      this.city_name == "" ||
      this.city_name == null ||
      this.user_selected_country == "" ||
      this.user_selected_country == null
    ) {
      // If City and or Country are empty show alert.
      this.emptyCityAlert();
    } else {
      // Create Object -> Save Settings as JSON Object
      let settings: object = {
        city_name: this.city_name,
        unit: this.unit,
        user_selected_country: this.user_selected_country.replace(/\s/g, ""), // Country chosen from Select (White spaces removed by regex replace)
        common_name: this.user_selected_country, // Country chosen from Select (White spaces removed by regex replace)
        country_code: this.country_code, // Value based on Array Filter Match (on change Select) to store the cca2 code
      };

      console.log(settings); // parse the JSON to Display the Object as Key Value Pairs to make them easier to view

      this.storage.set("settings", JSON.stringify(settings)); // converted to String

      console.log("Settings Were Updated!");
      console.log("City Name Set -> " + this.city_name);
      console.log("Country Code Set -> " + this.country_code);
      console.log("Unit Set -> " + this.unit);
      console.log("Country Set -> " + this.user_selected_country);
      this.navCtrl.pop(); // Remove item from stack and return to home.
      console.log(settings); // parse the JSON to Display the Object as Key Value Pairs to make them easier to view
    }
  }
  // Show the Clear Button
  showReset() {
    this.cityFilled = false;
    this.waitForUpdate = false;
  }

  clearCity() {
    this.textInput = null;
    this.city_name = null;
    console.log("Inputs Reset!");
  }
  connectionErrorToast() {
    this.toastOptions = {
      message:
        "❌ This Application Requires an Internet Connection. Please Check Your Connection!",
      position: "top",
      duration: 4000,
      showCloseButton: true,
    };
    this.toastCtrl.create(this.toastOptions).present();
  }

  deleteStorage() {
    this.storage.clear();
    this.toastOptions = {
      message: "✔️ Storage Cleared!",
      position: "top",
      duration: 2000,
      showCloseButton: true,
    };
    this.toastCtrl.create(this.toastOptions).present();
    // Reload Window
    window.location.reload();
  }
  pleaseWait() {
    this.toastOptions = {
      message: "✔️ Location Updated!",
      position: "top",
      duration: 2000,
      showCloseButton: true,
    };
    this.toastCtrl.create(this.toastOptions).present();
  }
}
