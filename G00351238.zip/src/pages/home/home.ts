declare var google: any;
import { Component } from "@angular/core";
import { NavController, ToastController, ToastOptions } from "ionic-angular";
// Import Pages
import { SettingsPage } from "../settings/settings";
import { NewsPage } from "../news/news";
// Import Storage
import { Storage } from "@ionic/storage";
// Providers
import { WeatherProvider } from "../../providers/weather/weather";
import { CountryProvider } from "../../providers/country/country";
@Component({
  selector: "page-home",
  templateUrl: "home.html",
})
export class HomePage {
  // Page Title
  public title: string = "G00351238";
  // Today's Date Option to Display.
  // public displayCurrentDate: any;

  // Set Page Message Defaults.
  public citySet: boolean = true; // (hidden by default)
  public cityNotset: boolean = true; // (hidden by default)
  // Message Hidden when no Location Data is Saved.
  public cityNotSetmessage: string =
    "No City Selected. Please Enter City and Select Country in Settings.";

  // Main Config.
  public unit: string;
  public country_code: string;
  public countryFlag: string;
  public countryCommonName: string;

  // Weather Data Array Object Returned and made Accessable.
  weatherObject: any[];

  // Weather 'for' Instance Variables.
  city_name: string;
  user_selected_country: string;

  // City Not Found Handling (No Data returned for 'city_name')
  // Show city not found message as default ( hiding this message is handled in the API request on successful city weather result found )
  cityNotFound: boolean = true;
  cityNotFoundMessage: string = " not found, try another City in Settings.";
  mapDisplay: boolean = true; // Map Display (hidden by default)

  gridDisplay: boolean = true;
  // Toast
  toastOptions: ToastOptions;
  // Display Appropriate Temperature Unit Symbol
  public tempSymbol: string;

  // Coordinates For Google Map
  lat: number;
  lon: number;
  map: any;

  // Navigate to Settings Page
  openSettings() {
    this.navCtrl.push(SettingsPage);
  }

  // Navigate to News Page
  openNews() {
    this.navCtrl.push(NewsPage);
  }
  /*
    Navigating Lifecycle Events ->
    https://ionicframework.com/blog/navigating-lifecycle-events/
  */

  ionViewWillEnter() {
    // ionViewWillEnter is fired when entering a page, before it becomes active...
    console.log("[ionViewWillEnter] Home Page Entered, Loaded!");
    this.storage
      .get("settings")
      .then((data) => {
        if (data != null) {
          // settings Object is stored in Storage.
          // Retrieve elements of Object as JSON Strings
          let settings = JSON.parse(data);

          // Set fields/data on page.
          this.city_name = settings.city_name;
          this.unit = settings.unit;
          this.user_selected_country = settings.user_selected_country;
          this.country_code = settings.country_code;
          this.tempSymbol = this.getTempSymbol(data.unit);

          // Show Weather For City
          this.citySet = false; // Unhide the placeholder message data
          this.cityNotset = true; // Hide No City Selected Message

          console.log("Local Storage Accessed");
          console.log("The Following Settings (data) is Saved in JSON format:");
          console.log(data);

          // Run the getWeatherAndCountry function
          this.getWeatherAndCountry();
        } else {
          // Initial Message: No City or Country is Saved..
          this.cityNotset = false;
          // this.cityNotFound = true;
          console.log("Local Storage Accessed, Nothing is Saved!");
        }
      })
      .catch((error) => {
        alert("Error Accessing Local Storage on Home Page!");
        console.log(error);
      });
  }

  constructor(
    public navCtrl: NavController,
    private storage: Storage,
    private wp: WeatherProvider,
    private cp: CountryProvider,
    private toastCtrl: ToastController
  ) {
    // this.displayCurrentDate = Date.now(); // Display Current Date
  }

  getWeatherAndCountry() {
    this.wp
      .getWeather(this.city_name, this.user_selected_country, this.unit)
      .subscribe(
        (data) => {
          if (data) {
            console.log(
              "Weather Data for " +
                this.city_name +
                ", " +
                this.user_selected_country +
                " Returned in JSON format:"
            );
            // Display Complete Weather for Selected City in JSON object on the Console
            console.log(data);
            // Make the Complete Response Data Available for Accessing
            this.weatherObject = data.data;
            /*
            Fetch the country_code, lat, lon of the city_name in the user_selected_country from weatherbit.io in order to 
            integrate with newsrestcountries.com API to return Flag and Common Name
            */
            this.country_code = data.data[0].country_code; // Assign country_code
            this.lat = data.data[0].lat; // Assign lat (for google map)
            this.lon = data.data[0].lon; // Assign lon (for google map)
            console.log("Country Code -> " + this.country_code);
            console.log("Lat -> " + this.lat);
            console.log("Lon -> " + this.lon);

            // country_code from weathererbit is used as key to find Country Details (flag, common name) from restcountries
            this.cp.getCountry(this.country_code).subscribe(
              (data) => {
                if (data) {
                  console.log(
                    "Country Data for " +
                      this.country_code +
                      " Returned in JSON format:"
                  );
                  // Returns country data (all data  available about the country) with the matching [country_code]
                  console.log(data);
                  // What I'm mostly interested in bringing in for the moment here is the Flag & countryCommonName
                  // Set Country Flag
                  this.countryFlag = data[0].flags.png; // Country Flag
                  // Set Country Common Name
                  this.countryCommonName = data[0].name.common; // Country Common Name (for displaying country name unstripped of white space)
                  console.log(this.countryFlag); // Country Flag
                  console.log(this.countryCommonName); // Country Common Name

                  // Hide Initial Message of City not Found.
                  this.cityNotFound = true;
                  // Show the Weather Grid.
                  this.gridDisplay = false;
                  // Successful Run Display Toast.
                  this.weatherFoundToast();

                  // Google Maps Integration Start
                  // https://developers.google.com/maps/documentation/javascript/overview#maps_map_simple-html
                  // https://developers.google.com/maps/documentation/javascript/using-typescript
                  let coords = new google.maps.LatLng(this.lat, this.lon);
                  // alert(coords);
                  // Output Google Map with specific coordinates & settings to the #map element on page.
                  this.map = new google.maps.Map(
                    document.getElementById("map"),
                    {
                      center: coords,
                      zoom: 12,
                      mapTypeId: google.maps.MapTypeId.ROADMAP,
                    }
                  );
                  // https://developers.google.com/maps/documentation/javascript/markers
                  // let marker: google.maps.Marker = new google.maps.Marker({
                  let marker = google.maps.Marker;
                  marker = new google.maps.Marker({
                    map: this.map,
                    draggable: false,
                    animation: google.maps.Animation.DROP,
                    position: coords,
                  });
                  console.log(marker);
                  // Google Maps Integration Finish
                  // Successful -> Show the Map
                  this.mapDisplay = false;
                } else {
                  console.log("No Data Coming through REST Countries API");
                }
              },
              (error) => {
                this.connectionErrorToast();
                console.log(error);
              }
            );
          } else {
            console.log("No Data Coming through Weatherbit API");
            // City Not Found -> no result from API means City not Found.. show/hide appropriate elements on page.
            console.log(this.city_name + " City not Found!");
            this.citySet = true; // Show city not found element
            this.cityNotFound = false; // Show city not found message
            this.gridDisplay = true; // Hide grid
            this.mapDisplay = true; // Hide map
            // Unsuccessful toast
            this.cityNotFoundToast();
          }
        },
        (error) => {
          this.connectionErrorToast();
          console.log(error);
        }
      );
  }
  connectionErrorToast() {
    this.toastOptions = {
      message:
        "❌ Failed to Update! This Application Requires an Internet Connection. Please Check Connection!",
      position: "top",
      duration: 4000,
      showCloseButton: true,
    };
    this.toastCtrl.create(this.toastOptions).present();
  }
  cityNotFoundToast() {
    // Toast Message for City not Found.
    // https://ionicframework.com/docs/v3/api/components/toast/ToastController/
    // user_selected_country -> white space kept as retrieved from Select. (not from storage)
    this.toastOptions = {
      message:
        "❌ No weather found for " +
        this.city_name +
        ", " +
        this.user_selected_country +
        ". Please try another City in Settings.",
      position: "top",
      duration: 4000,
      showCloseButton: true,
    };
    this.toastCtrl.create(this.toastOptions).present();
  }
  weatherFoundToast() {
    // https://ionicframework.com/docs/v3/api/components/toast/ToastController/
    // countryCommonName -> white space kept as using common name direct from API. (not from storage)
    this.toastOptions = {
      message:
        "✔️ Weather found for " +
        this.city_name +
        ", " +
        this.countryCommonName +
        ".",
      position: "top",
      duration: 2000,
      showCloseButton: true,
      // cssClass: "color: red;",
    };
    this.toastCtrl.create(this.toastOptions).present();
  }

  getTempSymbol(unit: string): string {
    // Switch Statement to Display Correct Temperature Symbol based on Selected Metric in Settings
    switch (this.unit) {
      // https://www.toptal.com/designers/htmlarrows/symbols/degree-celsius/
      case "M":
        return "&#8451;";
      case "S":
        return "&#8490;";
      case "I":
        return "&#8457;";
      default:
        return "";
    }
  }
}
